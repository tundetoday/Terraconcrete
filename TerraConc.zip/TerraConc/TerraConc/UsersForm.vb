﻿Imports System.Management
Public Class UsersForm
    Public Property User As String
    Public Property AdminLoggedin As Boolean
    Public Property Userloggedin As Boolean
    Dim a As Integer, Display As String, Counter As Integer
    Dim NoOfAdmin As Integer = 3
    Dim CountTry As Integer = 0, No0fTry = 5, NewPassword As Boolean = True, Passvalid As Boolean = False, State As String

    Private Sub UsersForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            If Me.UserstableTableAdapter.CountQuery() = 0 Then
                Emptystate()
            Else
                DefaultState()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Sub Emptystate()
        Try
            If Me.UserstableTableAdapter.CountQuery() = 0 Then
                AdminLoggedin = True
                Dim C() As Control = {TbTitle, BtnAddNew, Btnsave, BtnCancel, BtnEditUser, BtnLaunch, BtnEditCredentials,
                Tbpassword, Tbpassword2, LbPass2, TbFN, TbLN, RdbAdmin, RdbUser, LbUserRole, Btnsave, BtnCancel, BtnEditUser, BtnLogin}
                For i = 0 To C.Length - 1
                    C(i).Visible = True
                Next
                Dim d() As Control = {BtnEditUser, GrpUserprofile, BtnLaunch, BtnEditCredentials, RdbAdmin, RdbUser, LbUserRole,
                    Btnsave, BtnCancel, BtnLogin, BtnLogin}
                For i = 0 To d.Length - 1
                    d(i).Enabled = False
                Next
                Dim f() As Control = {BtnAddNew, BtnClose}
                For i = 0 To f.Length - 1
                    f(i).Enabled = True
                Next
                'Dim E() As Control = {LbPass2, Tbpassword2}
                'For i = 0 To E.Length - 1
                '    E(i).Visible = False
                'Next
                User = TbFN.Text & " , " & TbLN.Text & " ."
                LbUser.Text = " "
                TbUserRole.Text = "Admin"
            End If
            Display = "The first registered user is an Administrator by default .
                       Only the administrator should fill in details here.Admistrators have a higher Access permission."
            LbLoginDisplay.Text = Display
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub BtnAddNew_Click(sender As Object, e As EventArgs) Handles BtnAddNew.Click
        Try
            GrpUserprofile.Enabled = True
            Dim C() As Control = {BtnAddNew, BtnEditCredentials, BtnClose, BtnLogin, BtnLaunch, BtnEditUser, RdbAdmin, RdbUser}
            For i = 0 To C.Length - 1
                C(i).Enabled = False
            Next
            Dim Q() As Control = {LabelDesig, LblFN, LblLN, TbFN, TbLN, TbTitle, TbUN, Tbpassword, LbPass2, Tbpassword2}
            For i = 0 To Q.Length - 1
                Q(i).Visible = True
                Q(i).Enabled = True
                'Q(i).BackColor = SystemColors.Window
            Next
            Tbpassword.Text = Tbpassword2.Text
            UserstableBindingSource.AddNew()
            Btnsave.Enabled = True
            BtnCancel.Enabled = True
            If Me.UserstableTableAdapter.CountQuery() = 0 Then
                RdbAdmin.Enabled = False
                RdbUser.Enabled = False
            Else
                RdbAdmin.Enabled = True
                RdbUser.Enabled = True
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Sub Profiledata()
        Try
            Dim Q() As TextBox = {TbFN, TbLN, TbTitle}
            For i = 0 To Q.Length - 1
                If Trim(Q(i).Text).Length = 0 Then
                    Q(i).BackColor = Color.Beige
                    Q(i).Clear()
                    Counter = Counter + 1
                Else
                    Q(i).BackColor = SystemColors.Window
                End If
            Next
            If Counter > 0 Then
                ClearPass()
                MessageBox.Show("Columns have to be filled!", "Enter Complete Details!")
                Passvalid = False
                Exit Sub
            Else
                Passvalid = True
            End If
        Catch ex As Exception

        End Try
    End Sub
    Sub Password()
        Try
            If Passvalid = False Then Exit Sub
            If Me.UserstableTableAdapter.CountQuery() = 0 Then TbUserRole.Text = "Admin"
            If Trim(TbUN.Text).Length < 5 Then
                ClearPass()

                Passvalid = False
                MessageBox.Show("Username cannot be less than 5 characters!", "Enter Correct Username Length!")
                Exit Sub
            ElseIf Trim(Tbpassword.Text).Length < 8 Or Trim(Tbpassword2.Text).Length < 8 Then
                ClearPass()
                Passvalid = False
                MessageBox.Show("Password must be greater than or equal to 8 Characters!", "Enter Correct Password Length!")
                Exit Sub
            ElseIf Tbpassword.Text <> Tbpassword2.Text Then
                ClearPass()
                Passvalid = False
                'CountTry = CountTry + 1
                MessageBox.Show("Password does not match!", "Incorrect Password!")
                Exit Sub
            ElseIf TbUserRole.Text.Length = 0 Then
                Passvalid = False
                MessageBox.Show("Select User Role.", "Specify User Type!")
                Exit Sub
                'Checks if its a new password
            ElseIf Tbpassword.Text = Tbpassword2.Text Then
                ClearPass()
                User = TbFN.Text & " ," & TbLN.Text & " ."
                TbPass.Text = Tbpassword.Text
                BtnAddNew.Enabled = True
                Btnsave.Enabled = False

                UserstableBindingSource.EndEdit()
                UserstableTableAdapter.Update(TerraConcDataSet.Userstable)
                If NewPassword = True Then
                    MessageBox.Show("Your Profile has been Created Successfully!", "New Profile added!")
                    Display = ""
                    LbLoginDisplay.Text = Display

                    Passvalid = True
                    Exit Sub
                Else
                    MessageBox.Show("Your login details has been changed Successfully!", "Change login details!")
                    BtnLaunch.Enabled = True
                    Exit Sub
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub
    Private Sub Btnsave_Click(sender As Object, e As EventArgs) Handles Btnsave.Click
        Try
            Counter = 0
            Profiledata()
            Password()
            If Passvalid = False Then
                If Me.UserstableTableAdapter.CountQuery() = 0 Then
                    Exit Sub
                End If
            Else
                AdminLoginstate()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub BtnClose_Click(sender As Object, e As EventArgs) Handles BtnClose.Click
        Try
            'Dim ans As DialogResult = MessageBox.Show(TbUN.Text & " ,Login UnSuccessful!", "Login Status!", MessageBoxButtons.RetryCancel)
            Dim ans As DialogResult = MessageBox.Show("Are you sure you want to quit?", "Confirm!", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If ans = DialogResult.Yes Then
                Me.Close()
            Else

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Sub InvalidPass()
        Try
            Dim p() As TextBox = {TbFN, TbLN, TbTitle, TbPass, TbPass2, Tbpassword, Tbpassword2, TbUN}
            For i = 0 To p.Length - 1
                If Trim(p(i).Text).Length = 0 Then
                    p(i).BackColor = Color.Beige
                    p(i).Clear()
                Else
                    p(i).BackColor = SystemColors.Window
                End If
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try
    End Sub
    Sub Validpass()
        Try
            Dim p() As TextBox = {TbFN, TbLN, TbTitle, TbPass, TbPass2, Tbpassword, Tbpassword2, TbUN}
            For i = 0 To p.Length - 1
                p(i).BackColor = SystemColors.Window
                p(i).Clear()
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Sub ClearPass()
        Try
            Dim p() As TextBox = {TbUN, Tbpassword, Tbpassword2}
            If Trim(TbUN.Text).Length < 5 Then
                TbUN.BackColor = Color.Beige
            Else
                TbUN.BackColor = SystemColors.Window
            End If
            If Trim(Tbpassword.Text).Length < 8 Or Trim(Tbpassword2.Text).Length < 8 Then
                Tbpassword.BackColor = Color.Beige
                Tbpassword2.BackColor = Color.Beige
                Tbpassword.Text = String.Empty
                Tbpassword2.Text = String.Empty

            Else
                Tbpassword.BackColor = SystemColors.Window
                Tbpassword2.BackColor = SystemColors.Window
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Sub Login()
        Try
            UserstableTableAdapter.FillByPassword(TerraConcDataSet.Userstable, TbUN.Text, Tbpassword.Text)
            If UserstableTableAdapter.CountPaswwordQuery(TbUN.Text, Tbpassword.Text) > 0 Then
                If TbUserRole.Text = "Admin" Then
                    AdminLoggedin = True
                    AdminLoginstate()
                    Exit Sub
                Else
                    Userloggedin = True
                    Userloginstate()
                    Exit Sub
                End If
                'MessageBox.Show()
                Tbpassword2.Text = Tbpassword.Text
            ElseIf Trim(Tbpassword.Text).Length = 0 Or Trim(TbUN.Text).Length = 0 Then
                MessageBox.Show("Enter Valid Username and Password!", "Login Status!")
                'MessageBox.Show("Password must be greater than or equal to 8 Characters!", "Wrong Username/Password!")

                Exit Sub
            ElseIf UserstableTableAdapter.CountPaswwordQuery(TbUN.Text, Tbpassword.Text) = 0 And CountTry < No0fTry Then
                ClearPass()
                CountTry = CountTry + 1
                MessageBox.Show("Re-Enter Username/Password!You have " & No0fTry - CountTry + 1 & " No of tries", "Incorrect Password!")
                Exit Sub
            ElseIf UserstableTableAdapter.CountPaswwordQuery(TbUN.Text, Tbpassword.Text) = 0 And CountTry = No0fTry Then
                ClearPass()
                MessageBox.Show("You have used up No of tries.Please Contact licencee for support.", "Incorrect Password!")
                Me.Close()
            End If


        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub BtnLogin_Click(sender As Object, e As EventArgs) Handles BtnLogin.Click
        Try
            Login()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
    Private Sub BtnCancel_Click(sender As Object, e As EventArgs) Handles BtnCancel.Click
        Try
            If Me.UserstableTableAdapter.CountQuery() = 0 Then
                Emptystate()
                ClearPass()
                UserstableBindingSource.CancelEdit()
                TerraConcDataSet.Userstable.RejectChanges()
                Exit Sub
            End If
            ClearPass()
            UserstableBindingSource.CancelEdit()
            TerraConcDataSet.Userstable.RejectChanges()
            UserstableBindingSource.Sort = "Userid"
            If TbUserRole.Text = "Admin" Then
                AdminLoginstate()
            Else
                Userloginstate()
            End If
            MessageBox.Show("Cancel Successful !", "Cancel Status")
            'DefaultState()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub BtnEdit_Click(sender As Object, e As EventArgs) Handles BtnEditUser.Click
        Try

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        AdminEditState()
    End Sub
    Sub DefaultState()
        Try
            Dim C() As Control = {TbTitle, TbFN, TbLN}
            For i = 0 To C.Length - 1
                C(i).Enabled = False
            Next
            Dim d() As Control = {BtnAddNew, Btnsave, BtnCancel, BtnLaunch, BtnEditUser, BtnEditCredentials, LbPass2, Tbpassword2, RdbAdmin, RdbUser, LbUserRole}
            For i = 0 To d.Length - 1
                d(i).Visible = False
            Next
            TbUN.Focus()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        UserstableBindingSource.Sort = "Userid"

    End Sub
    Sub AdminEditState()
        Try
            AdminLoggedin = True
            ClearPass()
            Dim C() As Control = {TbTitle, TbFN, TbLN, LbUserRole, RdbAdmin, RdbUser}
            For i = 0 To C.Length - 1
                C(i).Enabled = True
            Next
            Dim d() As Control = {BtnAddNew, Btnsave, BtnCancel, BtnEditUser, BtnEditCredentials,
                LbPass2, Tbpassword, Tbpassword2, RdbAdmin, RdbUser, LbUserRole}
            For i = 0 To d.Length - 1
                d(i).Visible = True
            Next
            Dim E() As Control = {Btnsave, BtnCancel, BtnEditUser, LbPass2, Tbpassword2}
            For i = 0 To E.Length - 1
                E(i).Enabled = True
            Next
            MessageBox.Show("Login Successful!", "Login Status!")

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub BtnLaunch_Click(sender As Object, e As EventArgs) Handles BtnLaunch.Click
        Try
            'TbUN.Clear()
            'TbPass.Clear()
            'Tbpassword.Clear()
            'Tbpassword2.Clear()
            Dim p As New ProjectForm
            p.ShowDialog()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub UserstableDataGridView_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles UserstableDataGridView.CellContentClick
        Try
            DefaultState()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub BtnEditCredentials_Click(sender As Object, e As EventArgs) Handles BtnEditCredentials.Click
        Try

            If NewPassword = True Then
                Dim ans As DialogResult = MessageBox.Show("Are you sure you change Login details?", "Confirm!", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                If ans = DialogResult.Yes Then
                    ClearPass()
                    Tbpassword.Enabled = True
                    Tbpassword2.Visible = True
                    Tbpassword2.Enabled = True
                    TbUN.Enabled = True
                    LbPass2.Visible = True
                    LbPass2.Enabled = True
                    BtnLaunch.Enabled = False
                    BtnLogin.Enabled = False
                    BtnEditCredentials.Text = "Enter New Login Details."
                    NewPassword = False
                    BtnAddNew.Enabled = False

                Else
                    Exit Sub
                End If
            ElseIf NewPassword = False Then
                Password()
                If Passvalid = True Then
                    If TbUserRole.Text = "Admin" Then
                        AdminLoginstate()
                    Else
                        Userloginstate()
                    End If
                    BtnLaunch.Enabled = True
                Else
                    Exit Sub
                End If
                BtnEditCredentials.Text = "Edit Login Details."

            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try
    End Sub

    Private Sub RdbAdmin_CheckedChanged(sender As Object, e As EventArgs) Handles RdbAdmin.CheckedChanged, RdbUser.CheckedChanged
        Try
            If RdbAdmin.Checked = True Then
                TbUserRole.Text = "Admin"
            ElseIf RdbUser.Checked = True Then
                TbUserRole.Text = "User"
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try
    End Sub

    Sub AdminLoginstate()
        Try
            Dim C() As Control = {LabelDesig, LblFN, LblLN, TbTitle, BtnAddNew, Btnsave, BtnCancel, BtnEditUser, BtnLaunch, BtnEditCredentials,
                Tbpassword, TbFN, TbLN, RdbAdmin, RdbUser, LbUserRole, Btnsave, BtnCancel, BtnEditUser, BtnLogin}
            For i = 0 To C.Length - 1
                C(i).Visible = True
                C(i).Enabled = False
            Next
            Dim d() As Control = {RdbAdmin, RdbUser, LbUserRole, Btnsave, BtnCancel, BtnLogin}
            For i = 0 To d.Length - 1
                d(i).Enabled = False
            Next
            Dim f() As Control = {BtnAddNew, BtnLaunch, BtnClose, BtnEditCredentials, BtnEditUser}
            For i = 0 To f.Length - 1
                f(i).Enabled = True
            Next
            Dim E() As Control = {LbPass2, Tbpassword2}
            For i = 0 To E.Length - 1
                E(i).Visible = False
            Next
            User = TbTitle.Text & " " & TbFN.Text & " , " & TbLN.Text & User & " ."
            LbUser.Text = "Current User : " & User
            'MessageBox.Show("Admin Login Successful!", "Login Status!")
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try
    End Sub
    Sub Userloginstate()
        Try
            Dim C() As Control = {LabelDesig, LblFN, LblLN, TbTitle, TbFN, TbLN, RdbAdmin, RdbUser, LbUserRole, TbUN, Tbpassword,
                Btnsave, BtnCancel, BtnEditUser, BtnLogin}
            For i = 0 To C.Length - 1
                C(i).Visible = True
                C(i).Enabled = False
            Next
            Dim d() As Control = {BtnAddNew, Btnsave, BtnCancel, BtnEditUser}
            For i = 0 To d.Length - 1
                d(i).Visible = False
            Next
            Dim E() As Control = {BtnLaunch, BtnEditCredentials, BtnClose}
            For i = 0 To E.Length - 1
                E(i).Visible = True
                E(i).Enabled = True
            Next
            User = TbTitle.Text & " " & TbFN.Text & " , " & TbLN.Text & User & " ."
            LbUser.Text = "Current User : " & User
            MessageBox.Show("User Login Successful!", "Login Status!")
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try
    End Sub

End Class