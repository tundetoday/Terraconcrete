﻿Imports System.IO
Public Class ProjectForm
    Dim Newproject, Valid As Boolean, y As Integer, Ans As String
    Private Sub ProjectForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.ProjectsTableTableAdapter.Fill(Me.TerraConcDataSet.ProjectsTable)
        Try
            If Me.ProjectsTableTableAdapter.Fill(Me.TerraConcDataSet.ProjectsTable) = 0 Then
                Lockstate()
            Else
                Me.ProjectsTableTableAdapter.Fill(Me.TerraConcDataSet.ProjectsTable)
                Defaultsate()
            End If
            ToolStripLabel1.Text = "Current User : " & UsersForm.User
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error !")
        End Try
    End Sub

    Private Sub BtnAddNew_Click(sender As Object, e As EventArgs) Handles BtnAddNew.Click, NewProjectToolStripMenuItem.Click
        Try
            Newproject = True
            EditState()
            ProjectsTableBindingSource.AddNew()
            ProjectsTableTableAdapter.Update(TerraConcDataSet.ProjectsTable)
            ProjectsTableBindingSource.Sort = "projectId"
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub BtnBack_Click(sender As Object, e As EventArgs) Handles BtnClose.Click, ExitApplicationToolStripMenuItem.Click
        Try
            If Newproject = False Then
                Me.Close()
                Exit Sub
            Else
                Ans = MessageBox.Show("You Currently have unsaved Information,are you sure you want to quit?", "Confirm!", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                If Ans = DialogResult.Yes Then
                    Me.Close()

                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try
    End Sub
    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        Try
            Dim c() As Control = {PlotNoTextBox, ProjectNameTextBox, ProjectAddressTextBox, CityTextBox, StateTextBox, CountryTextBox, ClientNameTextBox,
                ClientAddressTextBox, ContactPersonTextBox, ContactPhoneNoTextBox, ContactEmailTextBox, ProjectTypeTextBox}
            y = 0

            For x = 0 To c.Length - 1
                If Trim(c(x).Text).Length = 0 Then y = y + 1
            Next
            If y > 0 Then
                For x = 0 To c.Length - 1
                    If c(x).Text.Length = 0 Or c(x).Text.Trim = " " Then
                        c(x).BackColor = SystemColors.AppWorkspace
                    Else
                        c(x).BackColor = SystemColors.Window
                    End If
                Next
                MessageBox.Show("Enter Relevant Project Information !", "Incomplete Project Details!")
                Exit Sub
            Else
                For x = 0 To c.Length - 1
                    c(x).BackColor = SystemColors.Window
                Next
                If Newproject = True Then
                    LblCreatedBy.Text = UsersForm.User
                    LblProjectDate.Text = DateTime.Today
                    ProjectsTableBindingSource.EndEdit()
                    ProjectsTableTableAdapter.Update(TerraConcDataSet.ProjectsTable)
                    MessageBox.Show("Save Successful !", "Save Status")
                    'ProjectsTableBindingSource.Sort = "projectId"
                Else
                    LastModifiedOnLabel1.Text = DateTime.Today
                    LastModifiedByLabel1.Text = UsersForm.User
                    ProjectsTableBindingSource.EndEdit()
                    ProjectsTableTableAdapter.Update(TerraConcDataSet.ProjectsTable)
                    MessageBox.Show("Save Successful !", "Save Status")
                    'ProjectsTableBindingSource.Sort = "projectId"
                End If
            End If
            Defaultsate()
            Newproject = False
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub ViewBatchToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewBatchToolStripMenuItem.Click
        ShowBatch()
    End Sub
    Sub ShowBatch()
        Try
            If Not IsNumeric(ProjectIDTextBox.Text) Then
                MessageBox.Show("Select Valid Project.", "Project Error!")
            Else
                Dim f As New BatchForm
                f.PiD = CInt(ProjectIDTextBox.Text)
                f.ShowDialog()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub BtnShowBatch_Click(sender As Object, e As EventArgs) Handles BtnShowBatch.Click, ProjectsTableDataGridView.DoubleClick
        Try
            ShowBatch()
        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try
    End Sub

    Private Sub ProjectReportToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProjectReportToolStripMenuItem.Click
        Try
            If Me.ProjectsTableTableAdapter.Fill(Me.TerraConcDataSet.ProjectsTable) = 0 Then
                MessageBox.Show("No Projects Currently.", "Report error!")
            Else
                Dim f As New ConcreteForm
                f.AllProjects = True
                f.Show()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub BtnUserProfile_Click(sender As Object, e As EventArgs)
        Dim f As New UsersForm
        f.ShowDialog()
    End Sub
    Private Sub AllProjectsReportToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AllProjectsReportToolStripMenuItem.Click
        Try
            If Me.ProjectsTableTableAdapter.Fill(Me.TerraConcDataSet.ProjectsTable) = 0 Or Not IsNumeric(ProjectIDTextBox.Text) Then
                MessageBox.Show("No  Project Selected.", "Report error!")
            ElseIf BatchTableTableAdapter.CheckQuery(ProjectIDTextBox.Text) > 0 Then
                Dim f As New ConcreteForm
                f.Batchall = True
                f.PiD = ProjectIDTextBox.Text
                f.Show()
            Else
                MessageBox.Show("This Project Currently has no tested concrete specimens.", "Project Report!")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub BtnCancel_Click(sender As Object, e As EventArgs) Handles BtnCancel.Click
        Try
            If Newproject = True And Me.ProjectsTableTableAdapter.Fill(Me.TerraConcDataSet.ProjectsTable) = 0 Then
                Lockstate()
            ElseIf Me.ProjectsTableTableAdapter.Fill(Me.TerraConcDataSet.ProjectsTable) = 0 Then
                Lockstate()
            ElseIf Me.ProjectsTableTableAdapter.Fill(Me.TerraConcDataSet.ProjectsTable) > 0 Then
                Defaultsate()
                ProjectsTableBindingSource.CancelEdit()
                TerraConcDataSet.ProjectsTable.RejectChanges()
                ProjectsTableBindingSource.Sort = "projectId"
                Dim c() As Control = {PlotNoTextBox, ProjectNameTextBox, ProjectAddressTextBox, CityTextBox, StateTextBox, CountryTextBox, ClientNameTextBox,
               ClientAddressTextBox, ContactPersonTextBox, ContactPhoneNoTextBox, ContactEmailTextBox, ProjectTypeTextBox}
                For x = 0 To c.Length - 1
                    c(x).BackColor = SystemColors.Window
                Next
            End If
            Newproject = False
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try


    End Sub
    Sub Defaultsate()
        Try
            Dim c() As Control = {PlotNoTextBox, ProjectNameTextBox, ToolStrip, GrpMove, BtnClose, BtnCloseApp,
                BtnCancel, MenuStrip1, BtnAddNew, BtnShowBatch, ProjectsTableDataGridView, BtnEdit,
                ProjectsTableBindingNavigator}
            For x = 0 To c.Length - 1
                c(x).Enabled = True
            Next
            BtnSave.Enabled = False
            SearchComboBox.BackColor = SystemColors.Window
            SearchTextBox.BackColor = SystemColors.Window

            'SplitContainer1.Panel1.Enabled = False
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub StructureTypeTextBox_KeyPress(sender As Object, e As KeyPressEventArgs) Handles StateTextBox.KeyPress, ProjectNameTextBox.KeyPress, ProjectAddressTextBox.KeyPress, PlotNoTextBox.KeyPress, CountryTextBox.KeyPress, ContactPhoneNoTextBox.KeyPress, ContactPersonTextBox.KeyPress, ContactEmailTextBox.KeyPress, ClientNameTextBox.KeyPress, ClientAddressTextBox.KeyPress, CityTextBox.KeyPress
        Try
            Dim c() As Control = {PlotNoTextBox, ProjectNameTextBox, ProjectAddressTextBox, CityTextBox, StateTextBox, CountryTextBox, ClientNameTextBox,
               ClientAddressTextBox, ContactPersonTextBox, ContactPhoneNoTextBox, ContactEmailTextBox, ProjectTypeTextBox}
            For x = 0 To c.Length - 1
                If e.KeyChar = ChrW(Keys.Enter) Then
                    If CType(sender, Control).Name = c(x).Name Then
                        c(x + 1).Focus()
                        c(x + 1).Text = String.Empty
                        My.Computer.Audio.Stop()
                    End If
                End If
            Next

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub BtnEdit_Click(sender As Object, e As EventArgs) Handles BtnEdit.Click
        Try
            Dim s As Boolean = UsersForm.AdminLoggedin
            If s = True Then
                EditState()
                BtnEdit.Enabled = False
            Else
                MessageBox.Show("Only the administrator can edit details here.You need a higher Access permission.", "Admin Rights Required!")

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Sub EditState()
        Try
            Dim c() As Control = {ProjectsTableBindingNavigator, ToolStrip, GrpMove, ProjectsTableDataGridView, BtnClose, BtnCloseApp, BtnAddNew, MenuStrip1, BtnEdit, BtnShowBatch}

            For x = 0 To c.Length - 1
                c(x).Enabled = False
            Next
            Dim d() As Control = {SplitContainer1.Panel1, BtnSave, BtnCancel}
            For x = 0 To d.Length - 1
                d(x).Enabled = True
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub
    Sub Lockstate()
        Dim c() As Control = {SplitContainer1.Panel1, BtnCancel, BtnSave, BtnShowBatch, ProjectsTableDataGridView, BtnEdit,
                                   ProjectsTableBindingNavigator}
        For x = 0 To c.Length - 1
            c(x).Enabled = False
        Next
        MenuStrip1.Enabled = True
        BtnAddNew.Enabled = True
    End Sub

    Private Sub BtnFirst_Click(sender As Object, e As EventArgs) Handles BtnFirst.Click
        Try

            ProjectsTableBindingSource.MoveFirst()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            My.Computer.Audio.Stop()
        End Try
    End Sub

    Private Sub BtnPrev_Click(sender As Object, e As EventArgs) Handles BtnPrev.Click
        Try
            ProjectsTableBindingSource.MovePrevious()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub BtnNext_Click(sender As Object, e As EventArgs) Handles BtnNext.Click
        Try
            ProjectsTableBindingSource.MoveNext()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub BtnLast_Click(sender As Object, e As EventArgs) Handles BtnLast.Click
        Try
            ProjectsTableBindingSource.MoveLast()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub GoButton_Click(sender As Object, e As EventArgs) Handles GoButton.Click
        Try
            If Trim(SearchComboBox.Text).Length = 0 Then
                SearchComboBox.Focus()
                SearchComboBox.BackColor = Color.Beige
                SearchComboBox.ToolTipText = "Enter Valid Searh Text"
                MessageBox.Show("Select Search Criteria.", "Selection required!", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            Else
                SearchComboBox.BackColor = SystemColors.Window
            End If
            If Trim(SearchTextBox.Text).Length = 0 Then
                SearchTextBox.Focus()
                SearchTextBox.ToolTipText = "Enter Valid Searh Text"
                SearchTextBox.BackColor = Color.Beige
                MessageBox.Show("Enter search Text", "Enter Text!", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            Else
                SearchTextBox.BackColor = SystemColors.Window
            End If

            Select Case SearchComboBox.SelectedIndex
                Case 0 'Project Name
                    If ProjectsTableTableAdapter.FillByPname(Me.TerraConcDataSet.ProjectsTable, SearchTextBox.Text) = 0 Then
                        Me.ProjectsTableTableAdapter.Fill(Me.TerraConcDataSet.ProjectsTable)
                        MessageBox.Show("Search Text not found.", "Search Results!", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    Else
                        ProjectsTableTableAdapter.FillByPname(Me.TerraConcDataSet.ProjectsTable, SearchTextBox.Text)
                    End If
                Case 1 'Project Address
                    If ProjectsTableTableAdapter.FillByPLcn(Me.TerraConcDataSet.ProjectsTable, SearchTextBox.Text) = 0 Then
                        Me.ProjectsTableTableAdapter.Fill(Me.TerraConcDataSet.ProjectsTable)
                        MessageBox.Show("Search Text not found.", "Search Results!", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    Else
                        ProjectsTableTableAdapter.FillByPLcn(Me.TerraConcDataSet.ProjectsTable, SearchTextBox.Text)
                    End If
                Case 2 'State
                    If ProjectsTableTableAdapter.FillByState(Me.TerraConcDataSet.ProjectsTable, SearchTextBox.Text) = 0 Then
                        Me.ProjectsTableTableAdapter.Fill(Me.TerraConcDataSet.ProjectsTable)
                        MessageBox.Show("Search Text not found.", "Search Results!", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    Else
                        ProjectsTableTableAdapter.FillByState(Me.TerraConcDataSet.ProjectsTable, SearchTextBox.Text)

                    End If
                Case 3 'Country
                    If ProjectsTableTableAdapter.FillByCountry(Me.TerraConcDataSet.ProjectsTable, SearchTextBox.Text) = 0 Then
                        Me.ProjectsTableTableAdapter.Fill(Me.TerraConcDataSet.ProjectsTable)
                        MessageBox.Show("Search Text not found.", "Search Results!", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    Else
                        ProjectsTableTableAdapter.FillByCountry(Me.TerraConcDataSet.ProjectsTable, SearchTextBox.Text)

                    End If
                Case 4 'Created On
                    If ProjectsTableTableAdapter.FillByCreatedOn(Me.TerraConcDataSet.ProjectsTable, SearchTextBox.Text) = 0 Then
                        Me.ProjectsTableTableAdapter.Fill(Me.TerraConcDataSet.ProjectsTable)
                        MessageBox.Show("Search Text not found.", "Search Results!", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    Else
                        ProjectsTableTableAdapter.FillByCreatedOn(Me.TerraConcDataSet.ProjectsTable, SearchTextBox.Text)

                    End If
                Case 5 'Created By
                    If ProjectsTableTableAdapter.FillByCreatedBy(Me.TerraConcDataSet.ProjectsTable, SearchTextBox.Text) = 0 Then
                        Me.ProjectsTableTableAdapter.Fill(Me.TerraConcDataSet.ProjectsTable)
                        MessageBox.Show("Search Text not found.", "Search Results!", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    Else
                        ProjectsTableTableAdapter.FillByCreatedBy(Me.TerraConcDataSet.ProjectsTable, SearchTextBox.Text)

                    End If
            End Select
            SearchComboBox.Text = String.Empty
            SearchTextBox.Text = String.Empty
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Search Error!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub SplitContainer1_Panel1_Enter(sender As Object, e As EventArgs) Handles SplitContainer1.Panel1.Click, SplitContainer1.Panel1.DoubleClick, SplitContainer1.Panel1.MouseEnter, SplitContainer1.Panel1.Move, SplitContainer1.Panel1.MouseHover
        Try
            If UsersForm.TbUserRole.Text = "Admin" Then Exit Sub
            If Newproject = True Then
                SplitContainer1.Panel1.Enabled = True
            Else
                LbWarning.Text = "Only the administrator can edit details here.You need a higher Access permission."
                SplitContainer1.Panel1.Enabled = False
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub SplitContainer1_Panel1_MouseLeave(sender As Object, e As EventArgs) Handles SplitContainer1.Panel1.MouseLeave, SplitContainer1.Panel1.Leave
        Try
            If UsersForm.TbUserRole.Text = "Admin" Then Exit Sub
            SplitContainer1.Panel1.Enabled = True
            LbWarning.Text = String.Empty
        Catch ex As Exception

        End Try
    End Sub

    Private Sub FillBy1ToolStripButton_Click(sender As Object, e As EventArgs)
        Try
            Me.ProjectsTableTableAdapter.FillBy1(Me.TerraConcDataSet.ProjectsTable)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub ToolStripLabel_Click(sender As Object, e As EventArgs) Handles ToolStripLabel.Click
        Try
            SearchComboBox.Text = String.Empty
            SearchTextBox.Text = String.Empty
            Me.ProjectsTableTableAdapter.Fill(Me.TerraConcDataSet.ProjectsTable)
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error !")
        End Try
    End Sub
    Private Sub BtnCloseApp_Click(sender As Object, e As EventArgs) Handles ExitApplicationToolStripMenuItem.Click, BtnCloseApp.Click
        Try
            Dim ans As DialogResult = MessageBox.Show("Are you sure you want to quit?", "Confirm!", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If ans = DialogResult.Yes Then
                Application.Exit()
            Else
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error !")
        End Try
    End Sub


End Class
