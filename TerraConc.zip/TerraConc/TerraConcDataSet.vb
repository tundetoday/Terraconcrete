﻿


Partial Public Class TerraConcDataSet
End Class


Partial Public Class TerraConcDataSet
End Class

Namespace TerraConcDataSetTableAdapters

    Partial Public Class UserstableTableAdapter
    End Class
End Namespace
